
// App.js
import React, { useState } from "react";
import "./App.css";

function App() {
  const [loanAmount, setLoanAmount] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [loanTerm, setLoanTerm] = useState("");
  const [monthlyPayment, setMonthlyPayment] = useState(null);

  const calculatePayment = () => {
    const principal = parseFloat(loanAmount);
    const monthlyInterest = parseFloat(interestRate) / 100 / 12;
    const numberOfPayments = parseFloat(loanTerm) * 12;

    if (principal && monthlyInterest >= 0 && numberOfPayments) {
      const payment =
        (principal * monthlyInterest) /
        (1 - Math.pow(1 + monthlyInterest, -numberOfPayments));
      setMonthlyPayment(payment.toFixed(2));
    } else {
      setMonthlyPayment(null);
    }
  };

  return (
    <div className="app-container">
      <h1>Mortgage Calculator</h1>
      <p className="intro">
        Use this calculator to estimate your monthly mortgage payments. Fill
        in the details below.
      </p>

      <div className="calculator">
        <div className="input-group">
          <label htmlFor="loanAmount">Loan Amount (£)</label>
          <input
            type="number"
            id="loanAmount"
            value={loanAmount}
            onChange={(e) => setLoanAmount(e.target.value)}
            placeholder="Enter loan amount"
          />
        </div>

        <div className="input-group">
          <label htmlFor="interestRate">Interest Rate (%)</label>
          <input
            type="number"
            id="interestRate"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            placeholder="Enter annual interest rate"
          />
        </div>

        <div className="input-group">
          <label htmlFor="loanTerm">Loan Term (years)</label>
          <input
            type="number"
            id="loanTerm"
            value={loanTerm}
            onChange={(e) => setLoanTerm(e.target.value)}
            placeholder="Enter loan term"
          />
        </div>

        <button onClick={calculatePayment} className="calculate-btn">
          Calculate
        </button>

        {monthlyPayment && (
          <div className="result">
            <h2>Estimated Monthly Payment:</h2>
            <p>£{monthlyPayment}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
